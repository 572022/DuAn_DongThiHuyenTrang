<?php
return [
    'email_user' => 'danentang2025@gmail.com',
    'email_pass' => 'rrde yiiv ohhd dbfo', // Mật khẩu ứng dụng
];
